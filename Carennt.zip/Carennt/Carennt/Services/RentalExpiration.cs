﻿using Carennt.Data;
using Microsoft.EntityFrameworkCore;

namespace Carennt.Services
{
    public class RentalExpiration : BackgroundService
    {
        private readonly ILogger<RentalExpiration> _logger;
        private readonly IServiceProvider _services;

        public RentalExpiration(IServiceProvider services, ILogger<RentalExpiration> logger)
        {
            _services = services;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Rental Agreement Expiration Service is starting.");

            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("Rental Agreement Expiration Service is running.");

                try
                {
                    using (var scope = _services.CreateScope())
                    {
                        var dbContext = scope.ServiceProvider.GetRequiredService<CurenntDbContext>();

                        // Get rental agreements that are accepted and expired
                        var expiredRentalAgreements = await dbContext.RentalAgreements
                            .Where(ra => ra.IsAccepted && !ra.IsReturned && ra.RentalEndDate < DateTime.UtcNow)
                            .ToListAsync();

                        foreach (var rentalAgreement in expiredRentalAgreements)
                        {
                            // Update car availability status and rental agreement properties
                            var car = await dbContext.Cars.FindAsync(rentalAgreement.CarId);
                            if (car != null)
                            {
                                car.AvalabilityStatus = true;
                            }

                            rentalAgreement.IsReturned = true;
                        }

                        await dbContext.SaveChangesAsync();
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "An error occurred while processing rental agreement expiration.");
                }

                // Check every 5 minutes
                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }

            _logger.LogInformation("Rental Agreement Expiration Service is stopping.");
        }

    }
}
