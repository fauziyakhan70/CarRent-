﻿using Carennt.Models;
using Microsoft.EntityFrameworkCore;

namespace Carennt.Data
{
    public class CurenntDbContext : DbContext
    {
        public CurenntDbContext(DbContextOptions<CurenntDbContext> options) : base(options)
        {

        }

        public DbSet<CarModel> Cars { get; set; }
        public DbSet<UserModel> Users { get; set; }
        public DbSet<ReturnRequestModel> ReturnRequests { get; set; }
        public DbSet<RentalAgreementModel> RentalAgreements { get; set;}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Define relationships and foreign keys
            modelBuilder.Entity<RentalAgreementModel>()
                .HasOne(ra => ra.Car)
                .WithMany()
                .HasForeignKey(ra => ra.CarId);

            modelBuilder.Entity<RentalAgreementModel>()
                .HasOne(ra => ra.User)
                .WithMany()
                .HasForeignKey(ra => ra.UserId);

            modelBuilder.Entity<ReturnRequestModel>()
                .HasOne(rr => rr.RentalAgreement)
                .WithOne()
                .HasForeignKey<ReturnRequestModel>(rr => rr.RentalAgreementId);
        }
    }
}
