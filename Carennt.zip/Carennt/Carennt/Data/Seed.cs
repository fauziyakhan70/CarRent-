﻿using Carennt.Models;
using Microsoft.EntityFrameworkCore;

namespace Carennt.Data
{
    public class Seed
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using(var context = new CurenntDbContext(serviceProvider.GetRequiredService<DbContextOptions<CurenntDbContext>>()))
            {
                if (context.Cars.Any() || context.Users.Any())
                {
                    return;
                }
                var CarImageNames = new[] { "car1.jpg", "car2.jpg" };

                var cars = new[]
                {
                    new CarModel
                    {
                        Maker = "Kia",
                        Model = "Seltos",
                        Price = 1200.0m,
                        AvalabilityStatus = true,
                        CarImage = CarImageNames[0],
                    },

                     new CarModel
                    {
                        Maker = "Mahindra",
                        Model = "XUV700",
                        Price = 1000.0m,
                        AvalabilityStatus = true,
                        CarImage = CarImageNames[1],
                    }
                };
                context.Cars.AddRange(cars);

                var admin = new UserModel
                {
                    Email = "admin@gmail.com",
                    Password = "Admin@#123",
                    IsAdmin = true,
                };
                context.Users.Add(admin);

                // Seed user
                var user1 = new UserModel
                {
                    Email = "user@gmail.com",
                    Password = "User@#123",
                    IsAdmin = false,
                };
                context.Users.Add(user1);

                var user2 = new UserModel
                {
                    Email = "user2@gmail.com",
                    Password = "User2@#123",
                    IsAdmin = false,
                };
                context.Users.Add(user2);
                context.SaveChanges();
            }
        }
    }
}
