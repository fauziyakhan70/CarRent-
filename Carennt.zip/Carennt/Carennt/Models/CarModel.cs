﻿using System.ComponentModel.DataAnnotations;

namespace Carennt.Models
{
    public class CarModel
    {
        
        public int Id { get; set; }
        [Required]
        [StringLength(100)]
        public string Maker { get; set; }
        [Required]
        [StringLength(100)]
        public string Model { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        public bool AvalabilityStatus { get; set; }
        [Required]
        public string CarImage { get; set; }
    }
}
