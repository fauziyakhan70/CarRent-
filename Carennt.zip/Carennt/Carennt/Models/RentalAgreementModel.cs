﻿using System.ComponentModel.DataAnnotations;

namespace Carennt.Models
{
    public class RentalAgreementModel
    {
        [Key]
        public int RentalAgreementId { get; set; }  // Rental Agreement ID (Unique)

        [Required(ErrorMessage = "Car ID is required.")]
        public int CarId { get; set; }

        [Required(ErrorMessage = "User ID is required.")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Rental Start Date is required.")]
        public DateTime RentalStartDate { get; set; }

        [Required(ErrorMessage = "Rental End Date is required.")]
        public DateTime RentalEndDate { get; set; }

        [Required(ErrorMessage = "Total Cost is required.")]
        public decimal TotalCost { get; set; }

        public bool IsAccepted { get; set; }
        public bool IsReturned { get; set; }

        // Navigation properties
        public CarModel Car { get; set; }
        public UserModel User { get; set; }
    }
}
