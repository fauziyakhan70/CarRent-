﻿using System.ComponentModel.DataAnnotations;

namespace Carennt.Models
{
    public class UserModel
    {
        [Key]
        public int UserId { get; set; }  // User ID (Unique)

        [Required(ErrorMessage = "Username is required.")]
        [EmailAddress]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public bool IsAdmin { get; set; }
    }
}
