﻿using System.ComponentModel.DataAnnotations;

namespace Carennt.Models
{
    public class ReturnRequestModel
    {
        [Key]
        public int ReturnRequestId { get; set; }  // Return Request ID (Unique)

        [Required(ErrorMessage = "Rental Agreement ID is required.")]
        public int RentalAgreementId { get; set; }

        [Required(ErrorMessage = "Return Request Date is required.")]
        public DateTime ReturnRequestDate { get; set; }

        [Required(ErrorMessage = "Inspection Status is required.")]
        public bool IsInspectionCompleted { get; set; }

        // Navigation property
        public RentalAgreementModel RentalAgreement { get; set; }

    }
}
