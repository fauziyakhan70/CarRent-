﻿using Carennt.Data;
using Carennt.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Data;
using static Carennt.Controllers.RentController;

namespace Carennt.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly CurenntDbContext _context;

        public AdminController(CurenntDbContext context)
        {
            _context = context;
        }

        public class AdminUpdateAgreementDTO
        {
            [Required(ErrorMessage = "RentalStartDate is required.")]
            [DataType(DataType.DateTime, ErrorMessage = "RentalStartDate should be a valid date and time.")]
            public DateTime RentalStartDate { get; set; }

            [Required(ErrorMessage = "RentalEndDate is required.")]
            [DataType(DataType.DateTime, ErrorMessage = "RentalEndDate should be a valid date and time.")]
            public DateTime RentalEndDate { get; set; }

            [Required(ErrorMessage = "Total Cost is required.")]
            public decimal TotalCost { get; set; }
        }

        [HttpGet("rentalagreements")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<IEnumerable<RentalAgreementModel>>> GetAllRentalAgreements()
        {
            var rentalAgreements = await _context.RentalAgreements
                .Include(ra => ra.Car)
                .Include(ra => ra.User)
                .ToListAsync();

            return Ok(rentalAgreements);
        }

        [HttpPut("{rentalAgreementId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PutRentalAgreement(int rentalAgreementId, AdminUpdateAgreementDTO rentalAgreementDTO)
        {
            if (rentalAgreementDTO == null)
            {
                return BadRequest("Invalid request body.");
            }

            var rentalAgreement = await _context.RentalAgreements.FindAsync(rentalAgreementId);

            if (rentalAgreement == null)
            {
                return NotFound("Rental agreement not found.");
            }

            // Update rental agreement properties
            rentalAgreement.RentalStartDate = rentalAgreementDTO.RentalStartDate;
            rentalAgreement.RentalEndDate = rentalAgreementDTO.RentalEndDate;
            rentalAgreement.TotalCost = rentalAgreementDTO.TotalCost;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{rentalAgreementId}/{userId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteRentalAgreement(int rentalAgreementId)
        {
            var rentalAgreement = await _context.RentalAgreements.FindAsync(rentalAgreementId);

            if (rentalAgreement == null)
            {
                return NotFound("Rental agreement not found.");
            }
            
            var carId = rentalAgreement.CarId;
            var car = await _context.Cars.FindAsync(carId);

            car.AvalabilityStatus = true;

            _context.RentalAgreements.Remove(rentalAgreement);
            await _context.SaveChangesAsync();

            return NoContent();
        }


        [HttpPut("{returnRequestId}/completeInspection")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CompleteInspection(int returnRequestId)
        {
            var returnRequest = await _context.ReturnRequests.FindAsync(returnRequestId);

            if (returnRequest == null)
                return NotFound("Return request not found.");

            if(returnRequest.IsInspectionCompleted)
            {
                return BadRequest("Inspection for this return is already been done.");
            }
            // Update inspection status
            returnRequest.IsInspectionCompleted = true;

            // Update rental agreement and car status
            var rentalAgreement = await _context.RentalAgreements.FindAsync(returnRequest.RentalAgreementId);
            if(rentalAgreement.IsReturned)
            {
                return BadRequest("Car is already Returned");
            }
            if (rentalAgreement != null)
            {
                rentalAgreement.IsReturned = true;
            }

            var car = await _context.Cars.FindAsync(rentalAgreement.CarId);
            if (car != null)
            {
                car.AvalabilityStatus = true;
            }

            await _context.SaveChangesAsync();
           
            return Ok(new { message = "Inspection completed successfully. Rental agreement and car status updated." });
        }

    }
}
