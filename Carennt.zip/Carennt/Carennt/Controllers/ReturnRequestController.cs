﻿using Carennt.Data;
using Carennt.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Carennt.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReturnRequestController : ControllerBase
    {
        private readonly CurenntDbContext _context;

        public ReturnRequestController(CurenntDbContext context)
        {
            _context = context;
        }

        public class ReturnRequestDTO
        {
            [Required(ErrorMessage = "Rental Agreement ID is required.")]
            public int RentalAgreementId { get; set; }
        }


        [HttpPost("userId")]
        public async Task<IActionResult> RequestReturn([FromBody] ReturnRequestDTO returnRequestDTO,int userid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Check if the rental agreement exists
            var rentalAgreement = await _context.RentalAgreements.FindAsync(returnRequestDTO.RentalAgreementId);

            var returnRequestcheck = await _context.ReturnRequests.FindAsync(returnRequestDTO.RentalAgreementId);

            if (returnRequestcheck != null)
            {
                return BadRequest("You have already requested for return of this car.");
            }

            if (rentalAgreement == null)
            {
                return NotFound("Rental agreement not found.");
            }

            if (rentalAgreement.UserId != userid)
            {
                return Unauthorized("You are not Authorized to Request for Return.");
            }

            if( !rentalAgreement.IsAccepted)
            {
                return BadRequest("You can not request for a return firstly you have to Rent a Car.");
            }

            if(rentalAgreement.IsReturned)
            {
                return BadRequest("Car is already Returned");
            }

            // Create a return request
            var returnRequest = new ReturnRequestModel
            {
                RentalAgreementId = returnRequestDTO.RentalAgreementId,
                ReturnRequestDate = DateTime.UtcNow,
                IsInspectionCompleted = false // Assuming inspection is not completed initially
            };

            _context.ReturnRequests.Add(returnRequest);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Return request submitted successfully." });

        }




        //Admin apis

        [HttpGet]
        public async Task<ActionResult> GetReturnRequests()
        {
            var returnRequests = await _context.ReturnRequests
                .Include(rr => rr.RentalAgreement)
                .ThenInclude(ra => ra.Car)
                .ToListAsync();

            return Ok(returnRequests);
        }

    }
}
