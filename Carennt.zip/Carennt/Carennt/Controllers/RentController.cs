﻿using Carennt.Data;
using Carennt.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Carennt.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RentController : ControllerBase
    {
        private readonly CurenntDbContext _context;

        public RentController(CurenntDbContext context)
        {
            _context = context;
        }

        public class RentalAgreementRequestDTO
        {
            [Required(ErrorMessage = "CarId is required.")]
            [RegularExpression("^[0-9]+$", ErrorMessage = "CarId must be a valid integer.")]
            public int CarId { get; set; }

            [Required(ErrorMessage = "UserId is required.")]
            [RegularExpression("^[0-9]+$", ErrorMessage = "UserId must be a valid integer.")]
            public int UserId { get; set; }

            [Required(ErrorMessage = "RentalStartDate is required.")]
            [DataType(DataType.DateTime, ErrorMessage = "RentalStartDate should be a valid date and time.")]
            public DateTime RentalStartDate { get; set; }

            [Required(ErrorMessage = "RentalEndDate is required.")]
            [DataType(DataType.DateTime, ErrorMessage = "RentalEndDate should be a valid date and time.")]
            public DateTime RentalEndDate { get; set; }
        }

        public class UpdateAgreementDTO
        {
            [Required(ErrorMessage = "UserId is required.")]
            [RegularExpression("^[0-9]+$", ErrorMessage = "UserId must be a valid integer.")]
            public int UserId { get; set; }

            [Required(ErrorMessage = "RentalStartDate is required.")]
            [DataType(DataType.DateTime, ErrorMessage = "RentalStartDate should be a valid date and time.")]
            public DateTime RentalStartDate { get; set; }

            [Required(ErrorMessage = "RentalEndDate is required.")]
            [DataType(DataType.DateTime, ErrorMessage = "RentalEndDate should be a valid date and time.")]
            public DateTime RentalEndDate { get; set; }
        }

        public class UpdateIsAcceptedDTO
        {
            [Required(ErrorMessage = "UserId is required.")]
            [RegularExpression("^[0-9]+$", ErrorMessage = "UserId must be a valid integer.")]
            public int UserId { get; set; }

            [Required(ErrorMessage = "IsAccepted is required.")]
            public bool IsAccepted { get; set; }
        }

        [HttpGet("user/{userId}")]
        
        public async Task<ActionResult<IEnumerable<RentalAgreementModel>>> GetUserRentalAgreements(int userId)
        {
            var rentalAgreements = await _context.RentalAgreements
            .Where(ra => ra.UserId == userId)
            .Include(ra => ra.Car)
            .Include(ra => ra.User)
            .ToListAsync();

            if (rentalAgreements == null || rentalAgreements.Count == 0)
            {
                return NotFound("No rental agreements found for the user.");
            }

            return Ok(rentalAgreements);
        }

        // POST: api/RentalAgreement
        [HttpPost]
        
        public async Task<ActionResult<RentalAgreementModel>> PostRentalAgreement([FromForm] RentalAgreementRequestDTO rentalAgreementDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Ensure rental start date is in the future
            DateTime rentalStartDate = rentalAgreementDTO.RentalStartDate.Date;
            DateTime currentDate = DateTime.UtcNow.Date;

            if (rentalStartDate < currentDate)
            {
                return BadRequest("Rental start date must be today or in the future.");
            }

            // Ensure rental end date is after start date
            if (rentalAgreementDTO.RentalEndDate <= rentalAgreementDTO.RentalStartDate)
            {
                return BadRequest("Rental end date must be after the start date.");
            }

            var car = await _context.Cars.FindAsync(rentalAgreementDTO.CarId);
            if (car == null)
            {
                return NotFound("Car not found.");
            }

            var user = await _context.Users.FindAsync(rentalAgreementDTO.UserId);

            var rentalDuration = rentalAgreementDTO.RentalEndDate.Subtract(rentalAgreementDTO.RentalStartDate).Days; 
            var totalCost = rentalDuration * car.Price;

            var rentalAgreement = new RentalAgreementModel
            {
                CarId = rentalAgreementDTO.CarId,
                UserId = rentalAgreementDTO.UserId,
                RentalStartDate = rentalAgreementDTO.RentalStartDate,
                RentalEndDate = rentalAgreementDTO.RentalEndDate,
                TotalCost = totalCost,
                IsAccepted = false,
                IsReturned = true
            };

            _context.RentalAgreements.Add(rentalAgreement);
            await _context.SaveChangesAsync();

            return Ok(rentalAgreement);
        }


        [HttpPut("{rentalAgreementId}")]
        
        public async Task<IActionResult> PutRentalAgreement(int rentalAgreementId, [FromForm] UpdateAgreementDTO rentalAgreementDTO)
        {
            if (rentalAgreementDTO == null || rentalAgreementDTO.UserId <= 0)
            {
                return BadRequest("Invalid request body.");
            }

            var rentalAgreement = await _context.RentalAgreements.FindAsync(rentalAgreementId);

            if (rentalAgreement == null)
            {
                return NotFound("Rental agreement not found.");
            }

            DateTime rentalStartDate = rentalAgreementDTO.RentalStartDate.Date;
            DateTime currentDate = DateTime.UtcNow.Date;

            if (rentalStartDate < currentDate)
            {
                return BadRequest("Rental start date must be today or in the future.");
            }

            // Ensure rental end date is after start date
            if (rentalAgreementDTO.RentalEndDate <= rentalAgreementDTO.RentalStartDate)
            {
                return BadRequest("Rental end date must be after the start date.");
            }

            // Check if the rental agreement is already accepted
            if (rentalAgreement.IsAccepted)
            {
                return BadRequest("Cannot edit an accepted rental agreement.");
            }

            // Check if the requested car ID and user ID match the ones associated with the rental agreement
            if (rentalAgreementDTO.UserId != rentalAgreement.UserId)
            {
                return BadRequest("Cannot change the car ID or user ID associated with this rental agreement.");
            }

            // Update rental agreement properties
            rentalAgreement.RentalStartDate = rentalAgreementDTO.RentalStartDate;
            rentalAgreement.RentalEndDate = rentalAgreementDTO.RentalEndDate;

            // Calculate total cost based on rental duration and car's rental price
            var car = await _context.Cars.FindAsync(rentalAgreement.CarId);
            if (car == null)
            {
                return NotFound("Car not found.");
            }

            var rentalDuration = rentalAgreementDTO.RentalEndDate.Subtract(rentalAgreementDTO.RentalStartDate).Days;
            rentalAgreement.TotalCost = rentalDuration * car.Price;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPut("{rentalAgreementId}/accept")]
        
        public async Task<IActionResult> AcceptRentalAgreement(int rentalAgreementId, UpdateIsAcceptedDTO updateIsAcceptedDTO)
        {
            var rentalAgreement = await _context.RentalAgreements.FindAsync(rentalAgreementId);

            if (rentalAgreement == null)
            {
                return NotFound("Rental agreement not found.");
            }

            if (rentalAgreement.UserId != updateIsAcceptedDTO.UserId)
            {
                return Unauthorized("You are not authorized to accept this rental agreement.");
            }

            DateTime rentalStartDate = rentalAgreement.RentalStartDate.Date;
            DateTime currentDate = DateTime.UtcNow.Date;

            if (rentalStartDate < currentDate)
            {
                return BadRequest("Rental start date must be today or in the future.");
            }

            // Ensure rental end date is after start date
            if (rentalAgreement.RentalEndDate <= rentalAgreement.RentalStartDate)
            {
                return BadRequest("Rental end date must be after the start date.");
            }

            // Check if the rental agreement is already accepted
            if (rentalAgreement.IsAccepted)
            {
                return BadRequest("Rental agreement is already accepted.");
            }

            rentalAgreement.IsAccepted = updateIsAcceptedDTO.IsAccepted;

            // Update car availability status
            var car = await _context.Cars.FindAsync(rentalAgreement.CarId);
            if (car == null)
            {
                return NotFound("Car not found.");
            }

            if (!car.AvalabilityStatus)
            {
                return BadRequest("Car is not available");
            }

            car.AvalabilityStatus = !updateIsAcceptedDTO.IsAccepted;
            rentalAgreement.IsReturned = !updateIsAcceptedDTO.IsAccepted;

            await _context.SaveChangesAsync();

            return NoContent();
        }


        [HttpDelete("{rentalAgreementId}/{userId}")]
        
        public async Task<IActionResult> DeleteRentalAgreement(int rentalAgreementId, int userId)
        {
            var rentalAgreement = await _context.RentalAgreements.FindAsync(rentalAgreementId);

            if (rentalAgreement == null)
            {
                return NotFound("Rental agreement not found.");
            }

            // Check if the rental agreement is already accepted
            if (rentalAgreement.IsAccepted)
            {
                return BadRequest("Cannot delete an accepted rental agreement.");
            }

            // Check if the requested user ID matches the one associated with the rental agreement
            if (rentalAgreement.UserId != userId)
            {
                return Unauthorized("You are not authorized to delete this rental agreement.");
            }

            _context.RentalAgreements.Remove(rentalAgreement);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }
}
